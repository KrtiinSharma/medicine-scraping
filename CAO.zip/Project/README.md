## Steps to run this program

1. python -m venv env

2. Windows: env\Scripts\activate
   Linux/Mac: source/env/activate

3. pip install -r requirements.txt

4. python main.py