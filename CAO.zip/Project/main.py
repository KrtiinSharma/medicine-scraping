from helper import *


headers = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'}
med_name = input("Enter the name of the medicine: ").lower()
med_name_new = ""
for i in med_name:
    if (i == " "):
        med_name_new += "%20"
    else:
        med_name_new += i
        
mg_1 = one_mg(f"https://www.1mg.com/search/all?name={med_name_new}", med_name)
apollo = apollo_meds(f"https://www.apollopharmacy.in/search-medicines/{med_name_new}", med_name)
tm = truemeds(f"https://www.truemeds.in/search/{med_name_new}", med_name)
pharm = pharmeasy(f"https://pharmeasy.in/search/all?name={med_name_new}", med_name)
nm = netmeds(f"https://www.netmeds.com/catalogsearch/result/{med_name_new}/all", med_name)

meds_dict = {
    "1mg" : mg_1,
    "Apollo" : apollo,
    "TrueMeds" : tm,
    "PharmEasy" : pharm,
    "Netmeds" : nm
}

with open("med_list.json", "w") as f:
    json.dump(meds_dict, f, indent = 2)